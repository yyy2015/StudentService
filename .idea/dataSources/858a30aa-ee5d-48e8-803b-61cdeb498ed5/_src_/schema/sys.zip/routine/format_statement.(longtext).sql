CREATE FUNCTION sys.format_statement(statement LONGTEXT)
  RETURNS LONGTEXT
  BEGIN IF @sys.statement_truncate_len IS NULL THEN SET @sys.statement_truncate_len = sys_get_config('statement_truncate_len', 64); END IF;  IF CHAR_LENGTH(statement) > @sys.statement_truncate_len THEN RETURN REPLACE(CONCAT(LEFT(statement, (@sys.statement_truncate_len/2)-2), ' ... ', RIGHT(statement, (@sys.statement_truncate_len/2)-2)), '
', ' '); ELSE  RETURN REPLACE(statement, '
', ' '); END IF; END;
